package interface_method;

import java.util.List;

import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.PdfPTable;

import table.Utilisateur;

public interface UtilisateurInterface {
	void create(Utilisateur utilisateur);
	Utilisateur findById(Long id);
	List<Utilisateur> findAll();
	void update(Utilisateur utilisateur);
	void delete(Long  ID); 
	int longueur();
	List<Utilisateur> getData(int page, int pageSize,String searchTerm);
	List<Integer> getResultPageNumbers(int pageSize, String searchTerm);
	String generatePDF(List<Utilisateur> productList);
	void addHeaderCell(PdfPTable table, String header,Font font);
	void addDataCell(PdfPTable table, String data); 
}
