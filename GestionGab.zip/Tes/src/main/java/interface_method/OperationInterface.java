package interface_method;

import java.util.List;

import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.PdfPTable;

import table.Operation;

public interface OperationInterface {
	List<Operation> findAll();
	void update(Operation operation);
	 void delete(Long    idOperation);
	 Operation findById(Long idOperation);
	 int longueur();
	 List<Operation> getData(int page, int pageSize, String searchTerm);
	 List<Integer> getResultPageNumbers(int pageSize, String searchTerm);
	 String generatePDF(List<Operation> productList);
	 void addHeaderCell(PdfPTable table, String header,Font font);
	 void addDataCell(PdfPTable table, String data);
	 
}
