package interface_method;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.PdfPTable;

import table.Compte;

public interface CompteInterface {
	void create(Compte compte);
	Compte findById(int idcompte);
	List<Compte> findAll();
	void update(Compte compte);
	void delete(Long  idcompte);
	void Depot(int id, double montant)throws IOException;
	void retrait(int id, double montant)throws IOException;
	void Transfer(int id, int comptedistinateur, double montant)throws IOException;
	Compte AffichageSolde(int id);
	boolean isValidUser(int id, String codePin);
	int longueur();
	List<Compte> getData(int page, int pageSize, String searchTerm);
	List<Integer> getResultPageNumbers(int pageSize, String searchTerm);
	List<Integer> Lister();
	List<Compte> Data(int page, int pageSize, String searchTerm)throws FileNotFoundException, DocumentException;
	String generatePDF(List<Compte> comptes);
	void addHeaderCell(PdfPTable table, String header,Font font);
	void addDataCell(PdfPTable table, String data);
	String  generatePDF(int id, double montant) throws IOException;
	String  generatePDFRetrait(int id, double montant)throws IOException;
	String  generatePDFTransfer(int id,int comptedistinateur,double montant)throws IOException;
	
}
