package interface_method;

import java.util.List;

import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.PdfPTable;

import table.Client;

public interface ClientInterface {
	void create(Client client);
	Client findById(int idclient);
	List<Client> findAll(int page,int pageSize);
	void update(Client client);
	void delete(int idclient);
	int longueur();
	List<Client> getData(int page, int pageSize,String searchTerm) ;
	List<Integer> getResultPageNumbers(int pageSize, String searchTerm);
	String generatePDF(List<Client> productList);
	void addHeaderCell(PdfPTable table, String header,Font font);
	void addDataCell(PdfPTable table, String data);
}
