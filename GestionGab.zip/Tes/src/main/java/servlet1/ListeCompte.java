package servlet1;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import service.CompteDao;
import table.Compte;


@WebServlet("/ListeCompte")
public class ListeCompte extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ListeCompte() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 CompteDao compte = new CompteDao();
		 request.setAttribute("comptes", compte.findAll());
		 
		 // Liste avec pagination 
			
			
		 	int pageSize = 1; // Nombre d'éléments par page
    int page = 1; // Page par défaut
    String searchTerm = request.getParameter("searchTerm");
    if (request.getParameter("page") != null) {
        page = Integer.parseInt(request.getParameter("page"));
    }
    List<Compte> comptes = compte.getData(page,pageSize,searchTerm);
    int totalResults = compte.longueur();
    int totalPages = (int) Math.ceil((double) totalResults / pageSize);

    List<Integer> resultPageNumbers = compte.getResultPageNumbers(pageSize, searchTerm);
    
    request.setAttribute("comptes", comptes);
    request.setAttribute("page", page);
    request.setAttribute("totalPages", totalPages);
    request.setAttribute("searchTerm", searchTerm);
   request.setAttribute("resultPageNumbers", resultPageNumbers);
   
   //  longeur  de table 
   request.setAttribute("totalResults",totalResults);
   

	// Stocker le chemin d'accès au PDF dans un attribut de requête

	String pdfFileName = "output_" + System.currentTimeMillis() + ".pdf";
	String pdfFilePath = "/" + pdfFileName; // Chemin d'accès relatif au fichier PDF accessible par le serveur web

	if (comptes != null) {
	    pdfFilePath =compte.generatePDF(comptes); // Assurez-vous que votre méthode generatePDF() prend le nom de fichier comme argument
	}

	// Déplacez le fichier PDF vers le répertoire de votre application web
	String webAppPath = getServletContext().getRealPath("/");
	File pdfFile = new File(pdfFilePath);
	pdfFile.renameTo(new File(webAppPath, pdfFileName));

	// Stocker le chemin d'accès relatif au PDF dans un attribut de requête
	request.setAttribute("pdfFileName", pdfFileName);
		 
		 
		 request.getRequestDispatcher("ListeCompte.jsp").forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
