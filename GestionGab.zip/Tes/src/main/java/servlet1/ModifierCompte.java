package servlet1;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.CompteDao;
import table.Compte;


@WebServlet("/ModifierCompte")
public class ModifierCompte extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
    public ModifierCompte() {
        super();
       
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int idcompte  = Integer.parseInt(request.getParameter("idcompte"));
        int  numeroCompte =Integer.parseInt(request.getParameter("numeroCompte"));
        String typeCompte = request.getParameter("typeCompte");
        int  codePin = Integer.parseInt(request.getParameter("codePin"));
        double  solde = Double.parseDouble(request.getParameter("solde"));
        String bank = request.getParameter("bank");
        

        Compte compte = new Compte();
        compte.setNumeroCompte(numeroCompte);
        compte.setTypeCompte(typeCompte);
        compte.setCodePin(codePin);
        compte.setSolde(solde);
        compte.setBank(bank);
        compte.setIdcompte(idcompte);

        CompteDao compte1 = new CompteDao();
       
			compte1.update(compte);
		

        //response.sendRedirect("read.jsp");
			response.sendRedirect(request.getContextPath() + "/ListeCompte");
	}

}
