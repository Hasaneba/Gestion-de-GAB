package servlet1;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.ClientDao;
import table.Client;


@WebServlet("/ModifierClient")
public class ModifierClient extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public ModifierClient() {
        super();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int  idclient = Integer.parseInt(request.getParameter("idclient"));
		String nom = request.getParameter("nom");
        String prenom = request.getParameter("prenom");
        String adress = request.getParameter("adress");
        int  cp =Integer.parseInt(request.getParameter("cp"));
        String ville = request.getParameter("ville");
        int  telephone = Integer.parseInt(request.getParameter("telephone"));
        Client client = new Client();
        client.setIdclient(idclient);
        client.setNom(nom);
        client.setPrenom(prenom);
        client.setAdress(adress);
        client.setCp(cp);
        client.setVille(ville);
        client.setTelephone(telephone);

        ClientDao clientDao = new ClientDao();
       
			clientDao.update(client);
		

        //response.sendRedirect("read.jsp");
			response.sendRedirect(request.getContextPath() + "/ListeClient");
	}

}
