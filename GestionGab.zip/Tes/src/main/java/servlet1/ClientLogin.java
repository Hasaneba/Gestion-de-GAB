package servlet1;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import service.CompteDao;


@WebServlet("/ClientLogin")
public class ClientLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public ClientLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 // Exemple d'identifiant utilisateur client 
	
		int  id = Integer.parseInt(request.getParameter("id"));
        String codePin = request.getParameter("codePin");
        CompteDao compte = new CompteDao();
        if (compte.isValidUser(id,codePin)) {
            // Successful login
        	HttpSession session = request.getSession(true); // Créer une nouvelle session si elle n'existe pas
        	session.setAttribute("id", id);
            response.sendRedirect("ClientNavBar.jsp");//ReadProductServle
        	//response.sendRedirect("ConsulterCompte?id=" + id);
        } else {
            // Failed login
            response.sendRedirect("failure.jsp");
        }
	}
	}

