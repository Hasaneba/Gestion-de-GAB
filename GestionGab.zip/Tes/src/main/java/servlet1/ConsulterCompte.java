package servlet1;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import service.CompteDao;
import table.Compte;


@WebServlet("/ConsulterCompte")
public class ConsulterCompte extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ConsulterCompte() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		   // int id  =Integer.parseInt(request.getParameter("id"));
		   
		    HttpSession session = request.getSession(false);
		    if(session != null) {
		    	 CompteDao compteDao = new CompteDao();
		    int id = (int) session.getAttribute("id");
		    Compte compte = compteDao.AffichageSolde(id);
		        request.setAttribute("compte1", compte);
		        request.getRequestDispatcher("Consulter.jsp").forward(request, response);
		    }
		    else {
		    	System.out.println("ne pas de connection");
		    }
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	              
	}

}
