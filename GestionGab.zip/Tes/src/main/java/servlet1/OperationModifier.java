package servlet1;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.OperationImp;
import table.Operation;


@WebServlet("/OperationModifier")
public class OperationModifier extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public OperationModifier() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Long   idOperation = Long.parseLong(request.getParameter("idOperation"));
		String  dateOperation = request.getParameter("dateOperation");
		  String typeOperation = request.getParameter("typeOperation");
		  double    montant = Double.parseDouble(request.getParameter("montant"));
		  OperationImp op = new OperationImp();
		 Operation p  = new Operation();
		 p.setIdOperation(idOperation);
		  p.setDateOperation(dateOperation);
		  p.setTypeOperation(typeOperation);
		  p.setMontant(montant);
		  op.update(p);
		  //response.sendRedirect("read.jsp");
			response.sendRedirect(request.getContextPath() + "/OperationAdmin");
	}

}
