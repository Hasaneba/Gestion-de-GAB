package servlet1;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import service.CompteDao;

import table.Compte;


@WebServlet("/AjouterCompte")
public class AjouterCompte extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public AjouterCompte() {
        super();
      
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
	
        int  numeroCompte =Integer.parseInt(request.getParameter("numeroCompte"));
        String typeCompte = request.getParameter("typeCompte");
        int  codePin = Integer.parseInt(request.getParameter("codePin"));
        double  solde = Double.parseDouble(request.getParameter("solde"));
        String bank = request.getParameter("bank");
        int  idclient = Integer.parseInt(request.getParameter("idclient"));
        

        Compte compte = new Compte();
        compte.setNumeroCompte(numeroCompte);
        compte.setTypeCompte(typeCompte);
        compte.setCodePin(codePin);
        compte.setSolde(solde);
        compte.setBank(bank);
        compte.setIdclient(idclient);

        CompteDao clientDao = new CompteDao();
       
			clientDao.create(compte);
		

        //response.sendRedirect("read.jsp");
			response.sendRedirect(request.getContextPath() + "/ListeCompte");
	}

}
