package servlet1;

import java.io.File;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import service.CompteDao;


@WebServlet("/TransferLargent")
public class TransferLargent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public TransferLargent() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// int comptesource = Integer.parseInt(request.getParameter("comptesource"));
		 HttpSession session = request.getSession(false);
		 if(session != null) {
		 int comptedistinateur = Integer.parseInt(request.getParameter("comptedistinateur"));
		    double montant = Double.parseDouble(request.getParameter("montant"));
		    int id = (int) session.getAttribute("id");
			CompteDao compte = new CompteDao();
			compte.Transfer(id,comptedistinateur,montant);
			// generate pdf  generatePDFTransfer
			// 
	        String pdfFilePath = compte.generatePDFTransfer(id,comptedistinateur,montant);
	        

	     // Obtenez le nom du fichier à partir du chemin du fichier PDF
	     String pdfFileName = new File(pdfFilePath).getName();

	     // Déplacer le fichier PDF vers le répertoire de votre application web
	     String webAppPath = getServletContext().getRealPath("/");
	     File pdfFile = new File(pdfFilePath);
	     pdfFile.renameTo(new File(webAppPath, pdfFileName));

	     // Rediriger vers la page JSP avec le nom du fichier PDF
	     request.setAttribute("pdfFileName", pdfFileName);
			
			request.getRequestDispatcher("Transfer.jsp").forward(request, response);
		 }
		 else {
			 System.out.println("le transfer ne pas effecteur");
		 }
	}

}
