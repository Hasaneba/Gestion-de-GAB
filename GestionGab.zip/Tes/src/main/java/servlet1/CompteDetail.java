package servlet1;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.CompteDao;
import table.Compte;


@WebServlet("/CompteDetail")
public class CompteDetail extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public CompteDetail() {
        super();
       
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int  idcompte = Integer.parseInt(request.getParameter("idcompte"));

        CompteDao client1 = new CompteDao();
        Compte  compte   = client1.findById(idcompte);

        request.setAttribute("compte", compte);
        request.getRequestDispatcher("CompteDetail.jsp").forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

}
