package servlet1;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.OperationImp;
import table.Operation;


@WebServlet("/Operationclient")
public class Operationclient extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public Operationclient() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		OperationImp e = new OperationImp();
		   int pageSize = 1; // Nombre d'éléments par page
	       int page = 1; // Page par défaut
	       String searchTerm = request.getParameter("searchTerm");
	       if (request.getParameter("page") != null) {
	          page = Integer.parseInt(request.getParameter("page"));
	       }
	       
	       List<Operation> o = e.getData(page,pageSize,searchTerm);
	       int totalResults = e.longueur();
	       int totalPages = (int) Math.ceil((double) totalResults / pageSize);

	       List<Integer> resultPageNumbers = e.getResultPageNumbers(pageSize, searchTerm);
	       
	       request.setAttribute("operations", o);
	       request.setAttribute("page", page);
	       request.setAttribute("totalPages", totalPages);
	       request.setAttribute("searchTerm", searchTerm);
	       request.setAttribute("resultPageNumbers", resultPageNumbers);
	       //  longeur  de table 
	       request.setAttribute("totalResults",totalResults);
		  
		 request.getRequestDispatcher("operation.jsp").forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
