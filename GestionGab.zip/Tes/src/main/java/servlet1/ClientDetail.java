package servlet1;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.ClientDao;
import table.Client;


@WebServlet("/ClientDetail")
public class ClientDetail extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public ClientDetail() {
        super();
      
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		int  idclient = Integer.parseInt(request.getParameter("idclient"));

        ClientDao client1 = new ClientDao();
        Client  client  = client1.findById(idclient);

        request.setAttribute("client", client);
        request.getRequestDispatcher("ClientDetail.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
