package servlet1;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.ClientDao;
import table.Client;



@WebServlet("/ListeClient")
public class ListeClient extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
 
    public ListeClient() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 ClientDao client = new ClientDao();
		// request.setAttribute("clients", client.findAll());
		 // pagination  String pageParam = request.getParameter("page");
	/*
	     int pageSize=1;
		
		 
		 String pageParam = request.getParameter("page");
		 int page = (pageParam != null && !pageParam.isEmpty()) ? Integer.parseInt(pageParam) : 1; // Valeur par défaut si le paramètre est null ou vide
		 String searchTerm = request.getParameter("searchTerm");
		
			request.setAttribute("clients",client.getData(page,pageSize,searchTerm)); 
			// Longeur de client 
		 	request.setAttribute("totalPages",client.longueur()); */
		 	int pageSize = 1; // Nombre d'éléments par page
        int page = 1; // Page par défaut
        String searchTerm = request.getParameter("searchTerm");
        if (request.getParameter("page") != null) {
            page = Integer.parseInt(request.getParameter("page"));
        }

        
        List<Client> clients = client.getData(page, pageSize, searchTerm);
        int totalResults = client.longueur();
        int totalPages = (int) Math.ceil((double) totalResults / pageSize);

        List<Integer> resultPageNumbers = client.getResultPageNumbers(pageSize, searchTerm);
        
        request.setAttribute("clients", clients);
        request.setAttribute("page", page);
        request.setAttribute("totalPages", totalPages);
        request.setAttribute("searchTerm", searchTerm);
        request.setAttribute("resultPageNumbers", resultPageNumbers);
        // longeur 
        request.setAttribute("totalResults", totalResults);
		 
		 
		/* 
		 int page = request.getParameter("page") != null ? Integer.parseInt(request.getParameter("page")) : 1;
	        String searchTerm = request.getParameter("searchTerm");
	        int pageSize = 1; // Taille de la page

	        List<Client> clients;
	        if (searchTerm != null && !searchTerm.isEmpty()) {
	            clients = client.getData(page, searchTerm);
	        } else {
	            clients = client.findAll(page, pageSize);
	        }
	        
	        int totalPages =  client.longueur();

	        request.setAttribute("clients", clients);
	        request.setAttribute("totalPages", totalPages);
	        request.setAttribute("searchTerm", searchTerm);
	        request.setAttribute("page", page);*/
        // Importation pdf 

    	String pdfFileName = "output_" + System.currentTimeMillis() + ".pdf";
    	String pdfFilePath = "/" + pdfFileName; // Chemin d'accès relatif au fichier PDF accessible par le serveur web

    	if (clients != null) {
    	    pdfFilePath =client.generatePDF(clients); // Assurez-vous que votre méthode generatePDF() prend le nom de fichier comme argument
    	}

    	// Déplacez le fichier PDF vers le répertoire de votre application web
    	String webAppPath = getServletContext().getRealPath("/");
    	File pdfFile = new File(pdfFilePath);
    	pdfFile.renameTo(new File(webAppPath, pdfFileName));

    	// Stocker le chemin d'accès relatif au PDF dans un attribut de requête
    	request.setAttribute("pdfFileName", pdfFileName);
       
		 request.getRequestDispatcher("ListeClient.jsp").forward(request, response);
		  
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
