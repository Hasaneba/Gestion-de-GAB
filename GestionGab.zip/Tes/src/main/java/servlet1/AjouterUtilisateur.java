package servlet1;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.UtilisatuerDao;
import table.Utilisateur;

@WebServlet("/AjouterUtilisateur")
public class AjouterUtilisateur extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public AjouterUtilisateur() {
        super();
      
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  String username = request.getParameter("username");
		  String email = request.getParameter("email");
		  String password = request.getParameter("password");
		  String role = request.getParameter("role");
		 UtilisatuerDao utilisateur  = new UtilisatuerDao();
		  Utilisateur utilisateur1  = new Utilisateur();
		  utilisateur1.setUsername(username);
		  utilisateur1.setEmail(email);
		  utilisateur1.setPassword(password);
		  utilisateur1.setRole(role);
		  utilisateur.create(utilisateur1);
		  //response.sendRedirect("read.jsp");
			response.sendRedirect(request.getContextPath() + "/ListeUtilisateur");
		  
		  
	}

}
