package service;

import table.Client;
import table.Operation;

public class Main {
	public static void main(String[] args) {
		
	//  barre de recherche pagination 
		
		//CompteDao k = new CompteDao();
		 ClientDao client = new ClientDao();
		 int idclient = 3;
		client.delete(idclient);
		// modifier 
		Client client1  = new Client(4, "bah",  "rajel","NDB",  6000,  "Zouerate",  27272727);
		client.update(client1);
				
		OperationImp p = new OperationImp();
		Operation p34 = new Operation(2L,"2025-03-02 17:22:18", "retrait",1200.0);
		
		p.update(p34);
        
    }
	
	
	   
}
