package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class ProductDAO {


   
    
    
    // login utilisateur 
    public boolean isValidUser(String username, String password) {
    try (Connection connection = SingletonConnection.getConn();) {
        String sql = "SELECT * FROM utilisateur WHERE username = ? AND password = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, username);
            statement.setString(2, password);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next();
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
    }
}
